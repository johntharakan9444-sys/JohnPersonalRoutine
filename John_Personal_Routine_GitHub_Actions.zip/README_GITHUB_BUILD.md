# Build from your phone with GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this project to it.
3. Open Actions and choose **Build John Personal Routine APK**.
4. Tap **Run workflow**.
5. When it finishes, open the run and download the artifact **John-Personal-Routine-debug-apk**.
6. Extract the artifact and install the APK on Android.
