# John Personal Routine

Editable Android workout tracker.

## Build
Open this folder in Android Studio, sync Gradle, then Build > Build APK(s).

## Included
- Day 1–Day 6 routine preloaded
- Editable workout names
- Add/delete/rename exercises
- Editable set count and targets
- Date-based workout records
- Weight and reps per set
- Completed-set tracking
- Local storage
- Workout history kept separate from the routine
