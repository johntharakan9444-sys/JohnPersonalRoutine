package com.john.personalroutine

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

private val Ink = Color(0xFF111827)
private val Muted = Color(0xFF64748B)
private val Accent = Color(0xFF4F46E5)
private val Soft = Color(0xFFF4F6FB)

private fun todayString() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun shiftDate(date: String, amount: Int): String = try {
    val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val d = f.parse(date) ?: Date()
    Calendar.getInstance().apply { time = d; add(Calendar.DAY_OF_MONTH, amount) }.let { f.format(it.time) }
} catch (_: Exception) { date }

data class ExerciseDef(var name:String, var sets:Int=4, var target:String="")
data class RoutineDay(var name:String, val exercises:MutableList<ExerciseDef>)
data class SetEntry(var weight:String="",var reps:String="",var done:Boolean=false)

private fun defaults() = mutableListOf(
    RoutineDay("Day 1", mutableListOf("Free Squat","Barbell/Power Squat","Leg Extension","Dumbbell Sumo Squat","Leg Press","Step-Ups","Alternate Dumbbell Curl","EZ Barbell Curl","Hammer Curl","Seated Calf Raise").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 2", mutableListOf("Incline Dumbbell Press","Incline Dumbbell Fly","Flat Bench Press","Pec Deck / Fly","Cable Crossover","Triceps Pulley Pushdown","Triceps Overhead Dumbbell Extension","Triceps Kickback").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 3", mutableListOf("Deadlift","Straight-Arm Pulldown","Seated Row","Single-Arm Dumbbell Rowing","Straight-Arm Pulldown","Dumbbell Shrug","Back Shrug").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 4", mutableListOf("Free Squat","Front Squat","Dumbbell Sumo Squat","Walking Lunges","Seated Leg Deadlift","Leg Curl","Seated Calf Raise").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 5", mutableListOf("Shoulder Dumbbell Press","Front Dumbbell Raise","Side Dumbbell Raise","Shoulder / Military Press","Reverse Fly","Barbell Curl","Preacher Curl","Overhead Dumbbell Extension").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 6", mutableListOf("Treadmill — 30 min","Twister — 5 min","Twist — 300 reps","Side Bend Down — 300 reps","Cross Trainer — 5 min","Stepper — 5 min").map{ExerciseDef(it)}.toMutableList())
)

class Store(ctx:Context) {
    private val p=ctx.getSharedPreferences("john_routine",0)
    fun saveRoutine(days:List<RoutineDay>) {
        val text=days.joinToString("\n") { d ->
            d.name.replace("|"," ")+"|"+d.exercises.joinToString(";") {
                "${it.name.replace("|"," ")}~${it.sets}~${it.target.replace("|"," ")}"
            }
        }
        p.edit().putString("routine",text).apply()
    }
    fun loadRoutine():MutableList<RoutineDay> {
        val raw=p.getString("routine",null) ?: return defaults()
        return try {
            raw.lines().filter{it.isNotBlank()}.map { line ->
                val x=line.split("|",limit=2)
                val ex=x.getOrElse(1){""}.split(";").filter{it.isNotBlank()}.map {
                    val q=it.split("~",limit=3)
                    ExerciseDef(q.getOrElse(0){""},q.getOrElse(1){"4"}.toIntOrNull()?:4,q.getOrElse(2){""})
                }.toMutableList()
                RoutineDay(x.getOrElse(0){"Day"},ex)
            }.toMutableList()
        } catch(_:Exception){ defaults() }
    }
    fun saveWorkout(date:String,day:Int,data:String)=p.edit().putString("workout:$date:$day",data).apply()
    fun loadWorkout(date:String,day:Int,exerciseCount:Int,setCounts:List<Int>):MutableList<MutableList<SetEntry>> {
        val out = MutableList(exerciseCount) { i -> MutableList(setCounts.getOrElse(i){4}) { SetEntry() } }
        val raw=p.getString("workout:$date:$day",null) ?: return out
        raw.lines().forEachIndexed { i,line ->
            if(i>=out.size || line.isBlank()) return@forEachIndexed
            line.split(";").filter{it.isNotBlank()}.forEachIndexed { j,cell ->
                if(j<out[i].size){ val q=cell.split(",",limit=3); out[i][j]=SetEntry(q.getOrElse(0){""},q.getOrElse(1){""},q.getOrElse(2){"false"}.toBoolean()) }
            }
        }
        return out
    }
    fun savePhoto(uri:String)=p.edit().putString("profile_photo",uri).apply()
    fun loadPhoto():String?=p.getString("profile_photo",null)
}

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContent{MaterialTheme(colorScheme = lightColorScheme(primary=Accent, background=Soft, surface=Color.White)) { App() }}
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(){
    val ctx=LocalContext.current
    val store=remember{Store(ctx)}
    var days by remember{mutableStateOf(store.loadRoutine())}
    var tab by remember{mutableIntStateOf(0)}
    var selectedDay by remember{mutableIntStateOf(0)}
    var date by remember{mutableStateOf(todayString())}
    var photoUri by remember{mutableStateOf(store.loadPhoto())}
    val photoPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri: Uri? ->
        uri?.let { try { ctx.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch(_:Exception){}; photoUri=it.toString(); store.savePhoto(it.toString()) }
    }

    Scaffold(containerColor=Soft, topBar={
        TopAppBar(title={Text("John Personal Routine",fontWeight=FontWeight.Bold)}, actions={
            TextButton(onClick={photoPicker.launch(arrayOf("image/*"))}){Text(if(photoUri==null)"Add photo" else "Change photo")}
        })
    }){pad->
        Column(Modifier.padding(pad).fillMaxSize()){
            ProfileHeader(photoUri) { photoPicker.launch(arrayOf("image/*")) }
            Row(Modifier.padding(horizontal=14.dp, vertical=8.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).padding(4.dp)){
                TabButton("Workout",tab==0){tab=0}
                TabButton("Edit Routine",tab==1){tab=1}
            }
            if(tab==0) Workout(days,selectedDay,{selectedDay=it},date,{date=it},store)
            else Editor(days,{days=it;store.saveRoutine(it)})
        }
    }
}

@Composable
private fun ProfileHeader(photoUri:String?, picker:()->Unit){
    Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){
        ProfilePhoto(photoUri,picker)
        Spacer(Modifier.width(12.dp))
        Column{ Text("John's training",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink); Text("Train • Track • Progress",color=Muted,fontSize=13.sp) }
    }
}

@Composable
private fun ProfilePhoto(uri:String?, onClick:()->Unit){
    Box(Modifier.size(58.dp).clip(CircleShape).border(2.dp,Accent,CircleShape).clickable{onClick()},contentAlignment=Alignment.Center){
        if(uri==null){ Text("J",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Accent) }
        else{
            var bitmap by remember(uri){mutableStateOf<android.graphics.Bitmap?>(null)}
            val context=LocalContext.current
            LaunchedEffect(uri){ bitmap=runCatching{context.contentResolver.openInputStream(Uri.parse(uri))?.use{BitmapFactory.decodeStream(it)}}.getOrNull() }
            if(bitmap!=null) Image(bitmap!!.asImageBitmap(),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop) else Text("J",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Accent)
        }
    }
}

@Composable private fun RowScope.TabButton(text:String,selected:Boolean,onClick:()->Unit){
    Button(onClick=onClick,modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),colors=ButtonDefaults.buttonColors(containerColor=if(selected) Accent else Color.Transparent,contentColor=if(selected) Color.White else Muted),elevation=ButtonDefaults.buttonElevation(0.dp)){Text(text,fontWeight=FontWeight.SemiBold)}
}

@Composable
fun Workout(days:List<RoutineDay>,selected:Int,onDay:(Int)->Unit,date:String,onDate:(String)->Unit,store:Store){
    val day=days[selected]
    val setCounts=day.exercises.map{it.sets}
    val entries=remember(day.name,date,setCounts){store.loadWorkout(date,selected,day.exercises.size,setCounts)}
    var saved by remember{mutableStateOf(false)}
    var editTick by remember{mutableIntStateOf(0)}
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=24.dp)){
        item{
            Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(20.dp)){
                Column(Modifier.padding(14.dp)){
                    Text("Workout log",fontWeight=FontWeight.Bold,fontSize=18.sp,color=Ink)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        OutlinedButton(onClick={onDate(shiftDate(date,-1))},modifier=Modifier.width(48.dp),contentPadding=PaddingValues(0.dp)){Text("‹")}
                        OutlinedTextField(date,onDate,label={Text("Date")},singleLine=true,modifier=Modifier.weight(1f))
                        OutlinedButton(onClick={onDate(shiftDate(date,1))},modifier=Modifier.width(48.dp),contentPadding=PaddingValues(0.dp)){Text("›")}
                    }
                    TextButton(onClick={onDate(todayString())}){Text("Today")}
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth().padding(top=2.dp)){days.forEachIndexed{i,d->FilterChip(selected=i==selected,onClick={onDay(i)},label={Text("D${i+1}")})}}
                    Spacer(Modifier.height(8.dp))
                    Button(onClick={
                        val data=entries.joinToString("\n"){s->s.joinToString(";"){ "${it.weight},${it.reps},${it.done}" }}
                        store.saveWorkout(date,selected,data);saved=true
                    },modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text(if(saved)"Workout saved ✓" else "Save workout",fontWeight=FontWeight.Bold)}
                }
            }
        }
        itemsIndexed(day.exercises){i,e->
            ExerciseCard(e, entries[i], editTick, onChanged={saved=false; editTick++})
        }
    }
}

@Composable
private fun ExerciseCard(e:ExerciseDef,sets:MutableList<SetEntry>, editTick:Int, onChanged:()->Unit){
    // Read editTick so changes to plain SetEntry fields trigger recomposition and keep text input visible.
    val _editTick = editTick
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(18.dp),elevation=CardDefaults.cardElevation(1.dp)){
        Column(Modifier.padding(12.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){Text(e.name,fontWeight=FontWeight.Bold,color=Ink,fontSize=16.sp);if(e.target.isNotBlank())Text("Target: ${e.target}",color=Muted,fontSize=12.sp)}
                Text("${sets.size} sets",color=Accent,fontSize=12.sp,fontWeight=FontWeight.SemiBold)
            }
            Spacer(Modifier.height(8.dp))
            sets.forEachIndexed{i,s->
                Row(Modifier.fillMaxWidth().padding(vertical=2.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)){
                    Text("${i+1}",Modifier.width(24.dp),fontWeight=FontWeight.Bold,color=Muted)
                    OutlinedTextField(value=s.weight,onValueChange={s.weight=it;onChanged()},label={Text("kg")},singleLine=true,modifier=Modifier.weight(1f))
                    OutlinedTextField(value=s.reps,onValueChange={s.reps=it;onChanged()},label={Text("reps")},singleLine=true,modifier=Modifier.weight(1f))
                    Checkbox(checked=s.done,onCheckedChange={s.done=it;onChanged()})
                }
            }
        }
    }
}

@Composable
fun Editor(days: MutableList<RoutineDay>, onSave: (MutableList<RoutineDay>) -> Unit) {
    var selected by remember { mutableIntStateOf(0) }
    var version by remember { mutableIntStateOf(0) }
    val day = days[selected]
    var dayName by remember(selected) { mutableStateOf(day.name) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
    ) {
        Text(
            "Customize your plan",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = Ink,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        Text(
            "Change exercises, sets and targets anytime.",
            color = Muted,
            fontSize = 13.sp
        )
        if (version > 0) {
            Text(
                "Unsaved changes",
                color = Accent,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(vertical = 10.dp)
        ) {
            days.forEachIndexed { i, _ ->
                FilterChip(
                    selected = i == selected,
                    onClick = {
                        selected = i
                        dayName = days[i].name
                    },
                    label = { Text("Day ${i + 1}") }
                )
            }
        }

        OutlinedTextField(
            value = dayName,
            onValueChange = { dayName = it },
            label = { Text("Workout name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 8.dp)
        ) {
            itemsIndexed(day.exercises) { i, e ->
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(10.dp)) {
                        OutlinedTextField(
                            value = e.name,
                            onValueChange = {
                                e.name = it
                                version++
                            },
                            label = { Text("Exercise") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            OutlinedTextField(
                                value = e.sets.toString(),
                                onValueChange = { v ->
                                    v.toIntOrNull()?.let {
                                        e.sets = it.coerceIn(1, 20)
                                        version++
                                    }
                                },
                                label = { Text("Sets") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = e.target,
                                onValueChange = {
                                    e.target = it
                                    version++
                                },
                                label = { Text("Target / reps / duration") },
                                singleLine = true,
                                modifier = Modifier.weight(2.5f)
                            )
                        }
                        TextButton(
                            onClick = {
                                day.exercises.removeAt(i)
                                version++
                            }
                        ) {
                            Text("Delete exercise", color = Color(0xFFDC2626))
                        }
                    }
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    day.exercises.add(ExerciseDef("New Exercise"))
                    version++
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("+ Exercise")
            }
            OutlinedButton(
                onClick = {
                    days.add(
                        RoutineDay(
                            "New Day",
                            mutableListOf(ExerciseDef("New Exercise"))
                        )
                    )
                    version++
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("+ Day")
            }
            Button(
                onClick = {
                    day.name = dayName
                    onSave(days.toMutableList())
                    version = 0
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Save")
            }
        }
    }
}
