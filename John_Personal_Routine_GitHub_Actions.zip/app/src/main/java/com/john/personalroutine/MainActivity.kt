package com.john.personalroutine

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class ExerciseDef(var name:String, var sets:Int=4, var target:String="")
data class RoutineDay(var name:String, val exercises:MutableList<ExerciseDef>)
data class SetEntry(var weight:String="",var reps:String="",var done:Boolean=false)

private fun defaults() = mutableListOf(
    RoutineDay("Day 1", mutableListOf("Free Squat","Barbell/Power Squat","Leg Extension","Dumbbell Sumo Squat","Leg Press","Step-Ups","Alternate Dumbbell Curl","EZ Barbell Curl","Hammer Curl","Seated Calf Raise").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 2", mutableListOf("Incline Dumbbell Press","Incline Dumbbell Fly","Flat Bench Press","Pec Deck / Fly","Cable Crossover","Triceps Pulley Pushdown","Triceps Overhead Dumbbell Extension","Triceps Kickback").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 3", mutableListOf("Deadlift","Straight-Arm Pulldown","Seated Row","Single-Arm Dumbbell Rowing","Straight-Arm Pulldown","Dumbbell Shrug","Back Shrug").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 4", mutableListOf("Free Squat","Front Squat","Dumbbell Sumo Squat","Walking Lunges","Seated Leg Deadlift","Leg Curl","Seated Calf Raise").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 5", mutableListOf("Shoulder Dumbbell Press","Front Dumbbell Raise","Side Dumbbell Raise","Shoulder / Military Press","Reverse Fly","Barbell Curl","Preacher Curl","Overhead Dumbbell Extension").map{ExerciseDef(it)}.toMutableList()),
    RoutineDay("Day 6", mutableListOf("Treadmill — 30 min","Twister — 5 min","Twist — 300 reps","Side Bend Down — 300 reps","Cross Trainer — 5 min","Stepper — 5 min").map{ExerciseDef(it)}.toMutableList())
)

class Store(ctx:Context) {
    private val p=ctx.getSharedPreferences("john_routine",0)
    fun saveRoutine(days:List<RoutineDay>) {
        val text=days.joinToString("\n") { d ->
            d.name.replace("|"," ")+"|"+d.exercises.joinToString(";") {
                "${it.name.replace("|"," ")}~${it.sets}~${it.target.replace("|"," ")}"
            }
        }
        p.edit().putString("routine",text).apply()
    }
    fun loadRoutine():MutableList<RoutineDay> {
        val raw=p.getString("routine",null) ?: return defaults()
        return try {
            raw.lines().filter{it.isNotBlank()}.map { line ->
                val x=line.split("|",limit=2)
                val ex=x.getOrElse(1){""}.split(";").filter{it.isNotBlank()}.map {
                    val q=it.split("~",limit=3)
                    ExerciseDef(q.getOrElse(0){""},q.getOrElse(1){"4"}.toIntOrNull()?:4,q.getOrElse(2){""})
                }.toMutableList()
                RoutineDay(x.getOrElse(0){"Day"},ex)
            }.toMutableList()
        } catch(_:Exception){ defaults() }
    }
    fun saveWorkout(date:String,day:Int,data:String)=p.edit().putString("workout:$date:$day",data).apply()
}

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContent{MaterialTheme{App()}}
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(){
    val ctx=androidx.compose.ui.platform.LocalContext.current
    val store=remember{Store(ctx)}
    var days by remember{mutableStateOf(store.loadRoutine())}
    var tab by remember{mutableStateOf(0)}
    var selectedDay by remember{mutableIntStateOf(0)}
    var date by remember{mutableStateOf(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()))}
    Scaffold(topBar={TopAppBar(title={Text("John Personal Routine")})}){pad->
        Column(Modifier.padding(pad).fillMaxSize()){
            Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                Button(onClick={tab=0}){Text("Workout")}
                OutlinedButton(onClick={tab=1}){Text("Edit Routine")}
            }
            if(tab==0) Workout(days,selectedDay,{selectedDay=it},date,{date=it},store)
            else Editor(days,{days=it;store.saveRoutine(it)})
        }
    }
}

@Composable
fun Workout(days:List<RoutineDay>,selected:Int,onDay:(Int)->Unit,date:String,onDate:(String)->Unit,store:Store){
    val day=days[selected]
    val entries=remember(day.name,date){day.exercises.map{it to MutableList(it.sets){SetEntry()}}}
    var saved by remember{mutableStateOf(false)}
    LazyColumn(Modifier.fillMaxSize().padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item{
            OutlinedTextField(date,onDate,label={Text("Date YYYY-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
                days.forEachIndexed{i,d->Button(onClick={onDay(i)}){Text("D${i+1}")}}
            }
            Spacer(Modifier.height(6.dp))
            Button(onClick={
                val data=entries.joinToString("\n"){(e,s)->e.name+"|"+s.joinToString(";"){ "${it.weight},${it.reps},${it.done}" }}
                store.saveWorkout(date,selected,data);saved=true
            },modifier=Modifier.fillMaxWidth()){Text(if(saved)"Saved ✓" else "Save Workout")}
        }
        itemsIndexed(entries){_,pair->
            val(e,sets)=pair
            Card(Modifier.fillMaxWidth()){
                Column(Modifier.padding(10.dp)){
                    Text(e.name,style=MaterialTheme.typography.titleMedium)
                    sets.forEachIndexed{i,s->
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                            Text("Set ${i+1}",Modifier.width(45.dp))
                            OutlinedTextField(s.weight,{s.weight=it;saved=false},label={Text("kg")},singleLine=true,modifier=Modifier.weight(1f))
                            OutlinedTextField(s.reps,{s.reps=it;saved=false},label={Text("reps")},singleLine=true,modifier=Modifier.weight(1f))
                            Checkbox(s.done,{s.done=it})
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Editor(days:MutableList<RoutineDay>,onSave:(MutableList<RoutineDay>)->Unit){
    var selected by remember{mutableIntStateOf(0)}
    var version by remember{mutableIntStateOf(0)}
    val day=days[selected]
    var dayName by remember(selected){mutableStateOf(day.name)}
    Column(Modifier.fillMaxSize().padding(10.dp)){
        Text("Edit Routine",style=MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement=Arrangement.spacedBy(4.dp),modifier=Modifier.padding(vertical=8.dp)){
            days.forEachIndexed{i,_->OutlinedButton(onClick={selected=i;dayName=days[i].name}){Text("D${i+1}")}}
        }
        OutlinedTextField(dayName,{dayName=it},label={Text("Workout name")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){
            itemsIndexed(day.exercises){i,e->
                Card(Modifier.fillMaxWidth()){
                    Column(Modifier.padding(8.dp)){
                        OutlinedTextField(e.name,{e.name=it;version++},label={Text("Exercise")},singleLine=true,modifier=Modifier.fillMaxWidth())
                        Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){
                            OutlinedTextField(e.sets.toString(),{v->v.toIntOrNull()?.let{e.sets=it.coerceIn(1,20);version++}},label={Text("Sets")},singleLine=true,modifier=Modifier.weight(1f))
                            OutlinedTextField(e.target,{e.target=it;version++},label={Text("Target / reps / duration")},singleLine=true,modifier=Modifier.weight(2f))
                        }
                        TextButton(onClick={day.exercises.removeAt(i);version++}){Text("Delete exercise")}
                    }
                }
            }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
            Button(onClick={day.exercises.add(ExerciseDef("New Exercise"));version++},modifier=Modifier.weight(1f)){Text("Add Exercise")}
            Button(onClick={days.add(RoutineDay("New Day",mutableListOf(ExerciseDef("New Exercise"))));version++},modifier=Modifier.weight(1f)){Text("Add Day")}
            Button(onClick={day.name=dayName;onSave(days.toMutableList())},modifier=Modifier.weight(1f)){Text("Save")}
        }
    }
}
